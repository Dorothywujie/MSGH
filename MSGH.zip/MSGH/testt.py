import torch
import numpy as np
from collections import OrderedDict

weight = torch.load("model/pvig_s_82.1.pth.tar")

print(weight.keys())
keys = list(weight.keys())
for item in weight:
    if "prediction" in item:
        keys.remove(item)

new_state = OrderedDict()
for item in keys:
    new_state[item] = weight[item]

print(new_state.keys())
# print(new_state)