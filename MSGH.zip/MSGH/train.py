import argparse
import logging
import os
import random
import numpy as np
import torch
import torch.backends.cudnn as cudnn
from collections import OrderedDict
from trainer import trainer_ACDC
from pyramid_vig import ViG_Seg_Modeling
from pyramid_vig import CONFIG as CONFIG_VIG_Seg

parser = argparse.ArgumentParser()
#### 数据集切换
# parser.add_argument('--dataset', type=str,
#                     default='Synapse', help='experiment_name')
parser.add_argument('--dataset', type=str,
                    default='ACDC', help='experiment_name')
# parser.add_argument('--dataset', type=str,
#                     default='LA', help='experiment_name')
### 初始化部分
parser.add_argument('--root_path', type=str,
                    default='/home/hehe/Medical_Program/TransUnet/project_TransUNet/data/ACDC',
                    help='root dir for data')
parser.add_argument('--list_dir', type=str,
                     default='./lists/lists_ACDC', help='list dir')
parser.add_argument('--num_classes', type=int,
                    default=9, help='output channel of network')
## 模型参数部分
parser.add_argument('--pretrained', type=bool, default=True, help="feature channels for feature uncertainty")
parser.add_argument('--pretrained_path', type=str, default=None, help="feature channels for feature uncertainty")
parser.add_argument('--max_iterations', type=int,
                    default=30000, help='maximum epoch number to train')
parser.add_argument('--max_epochs', type=int,
                    default=1500, help='maximum epoch number to train')
parser.add_argument('--batch_size', type=int, default=14, help='batch_size per gpu')
parser.add_argument('--gpu0_bsz', type=int, default=6,help='batch size on gpu 0')
parser.add_argument('--n_gpu', type=int, default=8, help='total gpu')
parser.add_argument('--deterministic', type=int, default=1,
                    help='whether use deterministic training')
parser.add_argument('--base_lr', type=float, default=0.07, #0.001
                    help='segmentation network learning rate')
parser.add_argument('--img_size', type=int,
                    default=224, help='input patch size of network input, LA set as 112')
parser.add_argument('--seed', type=int,
                    default=42, help='random seed')
parser.add_argument('--n_skip', type=int,
                    default=3, help='using number of skip-connect, default is num')
parser.add_argument('--model_name', type=str,
                    default='pvig_s_224_gelu', help='select one vit model')


args = parser.parse_args()

if __name__ == "__main__":
    if not args.deterministic:
        cudnn.benchmark = True
        cudnn.deterministic = False
    else:
        cudnn.benchmark = False
        cudnn.deterministic = True
    #os.environ["CUDA_VISIBLE_DEVICES"] = "0"
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)
    dataset_name = args.dataset

    snapshot_path = "../model/train"

    dataset_config = {
        'Synapse': {
            'root_path': '../data/Synapse/train_npz',
            'list_dir': './lists/lists_Synapse',
            'img_size': 224,
            'num_classes': 9,
        },
        'ACDC': {
            'root_path': '../data/ACDC',
            'list_dir': './lists/lists_acdc',
            'img_size': 224,
            'num_classes': 4,
        },
        'LA': {
            'root_path': "../data/LA",
            'list_dir': "./lists/list_LA",
            'img_size': 112,
            'num_classes': 2
        }
    }

    args.num_classes = dataset_config[dataset_name]['num_classes']
    args.root_path = dataset_config[dataset_name]['root_path']
    args.list_dir = dataset_config[dataset_name]['list_dir']
    args.img_size = dataset_config[dataset_name]['img_size']

    config_vig = CONFIG_VIG_Seg[args.model_name]
    config_vig.n_classes = args.num_classes
    config_vig.n_skip = args.n_skip
    config_vig.gpu0_bsz = args.gpu0_bsz

    net = ViG_Seg_Modeling(config_vig).cuda()

    optimizer = None
    # epoch = 0
    if True:    # 加载效果最好的checkpoint
        path_checkpoint = "/data/workspace/jie.wu/vig_sc_version01/model/train/epoch_949.pth"
        ckpt = torch.load(path_checkpoint, map_location='cpu')
        new_state_dict = {}
        # for k, v in ckpt['state_dict'].items():
        for k, v in ckpt.items():
            new_state_dict[k[7:]] = v
        net.load_state_dict(new_state_dict)
        # optimizer = ckpt['optimizer']
        # epoch = ckpt['epoch'] + 1
        args.pretrained = False


    if args.pretrained is True:
        args.pretrained_path = config_vig.pretrained_path
        weight = torch.load(args.pretrained_path)
        keys_list = list(weight.keys())
        new_list = filter(lambda x: "prediction" not in x, keys_list)
        new_list = filter(lambda x: "stem" not in x, new_list)
        new_state = OrderedDict()
        for item in new_list:
            new_state[item] = weight[item]
        net.encoder.load_state_dict(new_state, strict=False)

    trainer = {'ACDC': trainer_ACDC}
    trainer[dataset_name](args, net, snapshot_path)
