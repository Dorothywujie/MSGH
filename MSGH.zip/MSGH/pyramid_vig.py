# 2022.06.17-Changed for building ViG model
#            Huawei Technologies Co., Ltd. <foss@huawei.com>
# !/usr/bin/env python
# -*- coding: utf-8 -*-
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import Sequential as Seq

from timm.data import IMAGENET_DEFAULT_MEAN, IMAGENET_DEFAULT_STD
from timm.models.helpers import load_pretrained
from timm.models.layers import DropPath, to_2tuple, trunc_normal_
from timm.models.resnet import resnet26d, resnet50d
from timm.models.registry import register_model
import vig_seg_configs as config

from gcn_lib import Grapher, act_layer


def _cfg(url='', **kwargs):
    return {
        'url': url,
        'num_classes': 1000, 'input_size': (3, 224, 224), 'pool_size': None,
        'crop_pct': .9, 'interpolation': 'bicubic',
        'mean': IMAGENET_DEFAULT_MEAN, 'std': IMAGENET_DEFAULT_STD,
        'first_conv': 'patch_embed.proj', 'classifier': 'head',
        **kwargs
    }


default_cfgs = {
    'vig_224_gelu': _cfg(
        mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5),
    ),
    'vig_b_224_gelu': _cfg(
        crop_pct=0.95, mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5),
    ),
}


class FFN(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act='relu', drop_path=0.0):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Sequential(
            nn.Conv2d(in_features, hidden_features, 1, stride=1, padding=0),
            nn.BatchNorm2d(hidden_features),
        )
        self.act = act_layer(act)
        self.fc2 = nn.Sequential(
            nn.Conv2d(hidden_features, out_features, 1, stride=1, padding=0),
            nn.BatchNorm2d(out_features),
        )
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()

    def forward(self, x):
        shortcut = x
        x = self.fc1(x)
        x = self.act(x)
        x = self.fc2(x)
        x = self.drop_path(x) + shortcut
        return x  # .reshape(B, C, N, 1)


class Stem(nn.Module):
    """ Image to Visual Embedding
    Overlap: https://arxiv.org/pdf/2106.13797.pdf
    """

    def __init__(self, img_size=224, in_dim=1, out_dim=768, act='relu'):
        super().__init__()
        self.convs = nn.Sequential(
            nn.Conv2d(in_dim, out_dim // 2, 3, stride=2, padding=1),
            nn.BatchNorm2d(out_dim // 2),
            act_layer(act),
            nn.Conv2d(out_dim // 2, out_dim, 3, stride=2, padding=1),
            nn.BatchNorm2d(out_dim),
            act_layer(act),
            nn.Conv2d(out_dim, out_dim, 3, stride=1, padding=1),
            nn.BatchNorm2d(out_dim),
        )

    def forward(self, x):
        x = self.convs(x)
        return x


class Downsample(nn.Module):
    """ Convolution-based downsample
    """

    def __init__(self, in_dim=3, out_dim=768):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_dim, out_dim, 3, stride=2, padding=1),
            nn.BatchNorm2d(out_dim),
        )

    def forward(self, x):
        x = self.conv(x)
        return x


class Conv2dReLU(nn.Sequential):
    def __init__(
            self,
            in_channels,
            out_channels,
            kernel_size,
            padding=0,
            stride=1,
            use_batchnorm=True,
    ):
        conv = nn.Conv2d(
            in_channels,
            out_channels,
            kernel_size,
            stride=stride,
            padding=padding,
            bias=not (use_batchnorm),
        )
        relu = nn.ReLU(inplace=True)

        bn = nn.BatchNorm2d(out_channels)

        super(Conv2dReLU, self).__init__(conv, bn, relu)


class DecoderBlock(nn.Module):
    def __init__(self,
                in_channels,
                out_channels,
                skip_channels=0,
                use_batchnorm=True):
        super(DecoderBlock, self).__init__()
        self.conv1 = Conv2dReLU(
            in_channels=in_channels + skip_channels,
            out_channels=out_channels,
            kernel_size=3,
            padding=1,
            use_batchnorm=use_batchnorm,
        )

        self.conv2 = Conv2dReLU(
            in_channels=out_channels,
            out_channels=out_channels,
            kernel_size=3,
            padding=1,
            use_batchnorm=use_batchnorm,
        )

        self.up = nn.UpsamplingBilinear2d(scale_factor=2)

    def forward(self, x, skip=None):
        x = self.up(x)
        if skip is not None:
            x = torch.cat([x, skip], dim=1)
        x = self.conv1(x)
        x = self.conv2(x)
        return x


class SegmentationHead(nn.Sequential):

    def __init__(self, in_channels, out_channels, kernel_size=3, upsampling=1):
        conv2d = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, padding=kernel_size // 2)
        upsampling = nn.UpsamplingBilinear2d(scale_factor=upsampling) if upsampling > 1 else nn.Identity()
        super().__init__(conv2d, upsampling)


class DecoderCup(torch.nn.Module):
    def __init__(self, config):
        super(DecoderCup, self).__init__()
        self.config = config
        head_channels = 640
        output_channels = 400
        self.conv_more = Conv2dReLU(head_channels, output_channels, kernel_size=3, padding=1, use_batchnorm=True)

        decoder_channels = [400, 160, 80, 14, 14]
        in_channels = [output_channels] + list(decoder_channels[:-1])
        out_channels = decoder_channels
        self.feature_blocks = config.feature_blocks

        # if self.config.n_skip != 0:
        #     skip_channels = self.config.skip_channels
        #     for i in range(4-self.config.n_skip):
        #         for i in range(4-self.config.n_skip):
        #             skip_channels[3-i] = 0
        # else:
        #     skip_channels = [0, 0, 0, 0]
        if self.config.skip is True:
            skip_channels = [400, 160, 80, 0, 0]
        else:
            skip_channels = [0, 0, 0, 0, 0]

        blocks = [
            DecoderBlock(in_ch, out_ch, sk_ch) for in_ch, out_ch, sk_ch in zip(in_channels, out_channels, skip_channels)
        ]

        self.blocks = nn.ModuleList(blocks)

    def forward(self, hidden_state, features=None):
        b, c, w, h = hidden_state.size()
        x = self.conv_more(hidden_state)

        for i, decoder_block in enumerate(self.blocks):
            if features is not None and i < len(features):
                skip = features[i]
            else:
                skip = None
            x = decoder_block(x, skip=skip)
        return x


class DeepGCN(torch.nn.Module):
    def __init__(self, opt):
        super(DeepGCN, self).__init__()
        print(opt)
        k = opt.k
        act = opt.act
        norm = opt.norm
        bias = opt.bias
        epsilon = opt.epsilon
        stochastic = opt.use_stochastic
        conv = opt.conv
        emb_dims = opt.emb_dims
        drop_path = opt.drop_path

        blocks = opt.blocks
        self.feature_blocks = opt.feature_blocks
        self.n_blocks = sum(blocks)
        channels = opt.channels
        reduce_ratios = [4, 2, 1, 1]
        dpr = [x.item() for x in torch.linspace(0, drop_path, self.n_blocks)]  # stochastic depth decay rule 
        num_knn = [int(x.item()) for x in torch.linspace(k, k, self.n_blocks)]  # number of knn's k
        max_dilation = 49 // max(num_knn)

        self.stem = Stem(out_dim=channels[0], act=act)  # 将图像转成视觉嵌入补丁
        self.pos_embed = nn.Parameter(torch.zeros(1, channels[0], 224 // 4, 224 // 4))
        HW = 224 // 4 * 224 // 4

        self.backbone = nn.ModuleList([])
        idx = 0
        for i in range(len(blocks)):
            if i > 0:
                self.backbone.append(Downsample(channels[i - 1], channels[i]))
                HW = HW // 4
            for j in range(blocks[i]):
                self.backbone += [
                    Seq(Grapher(channels[i], num_knn[idx], min(idx // 4 + 1, max_dilation), conv, act, norm,
                                bias, stochastic, epsilon, reduce_ratios[i], n=HW, drop_path=dpr[idx],
                                relative_pos=True),
                        FFN(channels[i], channels[i] * 4, act=act, drop_path=dpr[idx])
                        )]
                idx += 1
        self.backbone = Seq(*self.backbone)

        # self.decoder = DecoderCup(image_size=224)
        #
        # self.segmentation_head = SegmentationHead(
        #     in_channels=14,
        #     out_channels=3,
        #     kernel_size=3,
        # )

        # self.prediction = Seq(nn.Conv2d(channels[-1], 1024, 1, bias=True),
        #                       nn.BatchNorm2d(1024),
        #                       act_layer(act),
        #                       nn.Dropout(opt.dropout),
        #                       nn.Conv2d(1024, opt.n_classes, 1, bias=True))
        self.model_init()

    def model_init(self):
        for m in self.modules():
            if isinstance(m, torch.nn.Conv2d):
                torch.nn.init.kaiming_normal_(m.weight)
                m.weight.requires_grad = True
                if m.bias is not None:
                    m.bias.data.zero_()
                    m.bias.requires_grad = True

    def forward(self, inputs):
        x = self.stem(inputs) + self.pos_embed
        B, C, H, W = x.shape
        feature_list = []
        for i in range(len(self.backbone)):
            x = self.backbone[i](x)
            if i in self.feature_blocks:
                feature_list.insert(0, x)
        # x_logits = self.decoder(x)
        # output = self.segmentation_head(x_logits)

        return x, feature_list
        # x = F.adaptive_avg_pool2d(x, 1)
        # return self.prediction(x).squeeze(-1).squeeze(-1)

class ViG_Seg_Modeling(nn.Module):
    def __init__(self, opt):
        super(ViG_Seg_Modeling, self).__init__()
        self.encoder = DeepGCN(opt=opt)
        self.encoder1 = DeepGCN(opt=opt)
        self.encoder2 = DeepGCN(opt=opt)
        
        self.decoder = DecoderCup(config=opt)
       # self.decoder1 = DecoderCup(config=opt)
        self.decoder2 = DecoderCup(config=opt)


        self.layer = nn.Sequential(
            nn.Conv1d(in_channels=49, out_channels=1, kernel_size=1, stride=1),
            nn.ReLU(inplace=True)
        )

        prev_dim = 640
        out_dim = 640
        self.pro = nn.Sequential(
            nn.Linear(prev_dim, prev_dim, bias=False),
            nn.BatchNorm1d(prev_dim),
            nn.ReLU(inplace=True),
            nn.Linear(prev_dim, out_dim, bias=False),
            nn.BatchNorm1d(out_dim),
            nn.ReLU(inplace=True),
            nn.Linear(out_dim, out_dim, bias=False),
            nn.BatchNorm1d(out_dim, affine=False)
        )
        # 预测头
        self.pred = nn.Sequential(
            nn.Linear(in_features=out_dim, out_features=out_dim, bias=False),
            nn.BatchNorm1d(out_dim),
            nn.ReLU(inplace=True),
            nn.Linear(out_dim, out_dim)
        )
        
        self.segmentation_head = SegmentationHead(in_channels=14, out_channels=opt.n_classes,kernel_size=3,)
        #self.segmentation_head1 = SegmentationHead(in_channels=14, out_channels=opt.n_classes,kernel_size=3,)
        self.segmentation_head2 = SegmentationHead(in_channels=14, out_channels=opt.n_classes,kernel_size=3,)


    def forward(self, inputs, inputs_aug1, inputs_aug2):
        x, feature_list = self.encoder(inputs)
        logits = self.decoder(x, feature_list)
        outputs = self.segmentation_head(logits)
         
        x_aug1, feature_aug1 = self.encoder1(inputs_aug1)
        x_aug2, feature_aug2 = self.encoder2(inputs_aug2)
        
        x_aug_1 = x_aug1
        x_aug_2 = x_aug2

        x_aug_1 = x_aug_1.view(x_aug_1.size(0), x_aug_1.size(1), -1).permute(0, 2, 1)
        x_aug_2 = x_aug_2.view(x_aug_2.size(0), x_aug_2.size(1), -1).permute(0, 2, 1)
        
        x_aug_1 = self.layer(x_aug_1)
        x_aug_2 = self.layer(x_aug_2)
        
        p_aug_1 = self.pro(x_aug_1[:, 0, :])
        p_aug_2 = self.pro(x_aug_2[:, 0, :])

        z_aug_1 = self.pred(p_aug_1)
        z_aug_2 = self.pred(p_aug_2)

        logits = self.decoder(x, feature_list)
        #logits1 = self.decoder1(x_aug1, feature_aug1)
        logits2 = self.decoder2(x_aug2, feature_aug2)


        outputs = self.segmentation_head(logits)
        #out1 = self.segmentation_head1(logits1)
        out2 = self.segmentation_head2(logits2)
         
        
        #return outputs, out1.detach(), out2, p_aug_1.detach(), p_aug_2.detach(), z_aug_1, z_aug_2 # 计算一致性损失

        return outputs, out2, p_aug_1.detach(), p_aug_2.detach(), z_aug_1, z_aug_2 # 最新版本的对比损失

CONFIG = {
    "pvig_s_224_gelu": config.get_pvig_s_224_gelu()
}

# @register_model
# def pvig_ti_224_gelu(pretrained=False, **kwargs):
#     class OptInit:
#         def __init__(self, num_classes=1000, drop_path_rate=0.0, **kwargs):
#             self.k = 9  # neighbor num (default:9)
#             self.conv = 'mr'  # graph conv layer {edge, mr}
#             self.act = 'gelu'  # activation layer {relu, prelu, leakyrelu, gelu, hswish}
#             self.norm = 'batch'  # batch or instance normalization {batch, instance}
#             self.bias = True  # bias of conv layer True or False
#             self.dropout = 0.0  # dropout rate
#             self.use_dilation = True  # use dilated knn or not
#             self.epsilon = 0.2  # stochastic epsilon for gcn
#             self.use_stochastic = False  # stochastic for gcn, True or False
#             self.drop_path = drop_path_rate
#             self.blocks = [2, 2, 6, 2]  # number of basic blocks in the backbone
#             self.channels = [48, 96, 240, 384]  # number of channels of deep features
#             self.n_classes = num_classes  # Dimension of out_channels
#             self.emb_dims = 1024  # Dimension of embeddings
#
#     opt = OptInit(**kwargs)
#     model = DeepGCN(opt)
#     model.default_cfg = default_cfgs['vig_224_gelu']
#     return model


# @register_model
# def pvig_s_224_gelu(pretrained=False, **kwargs):
#     class OptInit:
#         def __init__(self, num_classes=1000, drop_path_rate=0.0, **kwargs):
#             self.k = 9  # neighbor num (default:9)
#             self.conv = 'mr'  # graph conv layer {edge, mr}
#             self.act = 'gelu'  # activation layer {relu, prelu, leakyrelu, gelu, hswish}
#             self.norm = 'batch'  # batch or instance normalization {batch, instance}
#             self.bias = True  # bias of conv layer True or False
#             self.dropout = 0.0  # dropout rate
#             self.use_dilation = True  # use dilated knn or not
#             self.epsilon = 0.2  # stochastic epsilon for gcn
#             self.use_stochastic = False  # stochastic for gcn, True or False
#             self.drop_path = drop_path_rate
#             self.blocks = [2, 2, 6, 2]  # number of basic blocks in the backbone
#             self.channels = [80, 160, 400, 640]  # number of channels of deep features
#             self.n_classes = num_classes  # Dimension of out_channels
#             self.emb_dims = 1024  # Dimension of embeddings
#
#     opt = OptInit(**kwargs)
#     model = DeepGCN(opt)
#     model.default_cfg = default_cfgs['vig_224_gelu']
#     return model
#
#
# @register_model
# def pvig_m_224_gelu(pretrained=False, **kwargs):
#     class OptInit:
#         def __init__(self, num_classes=1000, drop_path_rate=0.0, **kwargs):
#             self.k = 9  # neighbor num (default:9)
#             self.conv = 'mr'  # graph conv layer {edge, mr}
#             self.act = 'gelu'  # activation layer {relu, prelu, leakyrelu, gelu, hswish}
#             self.norm = 'batch'  # batch or instance normalization {batch, instance}
#             self.bias = True  # bias of conv layer True or False
#             self.dropout = 0.0  # dropout rate
#             self.use_dilation = True  # use dilated knn or not
#             self.epsilon = 0.2  # stochastic epsilon for gcn
#             self.use_stochastic = False  # stochastic for gcn, True or False
#             self.drop_path = drop_path_rate
#             self.blocks = [2, 2, 16, 2]  # number of basic blocks in the backbone
#             self.channels = [96, 192, 384, 768]  # number of channels of deep features
#             self.n_classes = num_classes  # Dimension of out_channels
#             self.emb_dims = 1024  # Dimension of embeddings
#
#     opt = OptInit(**kwargs)
#     model = DeepGCN(opt)
#     model.default_cfg = default_cfgs['vig_224_gelu']
#     return model
#
#
# @register_model
# def pvig_b_224_gelu(pretrained=False, **kwargs):
#     class OptInit:
#         def __init__(self, num_classes=1000, drop_path_rate=0.0, **kwargs):
#             self.k = 9  # neighbor num (default:9)
#             self.conv = 'mr'  # graph conv layer {edge, mr}
#             self.act = 'gelu'  # activation layer {relu, prelu, leakyrelu, gelu, hswish}
#             self.norm = 'batch'  # batch or instance normalization {batch, instance}
#             self.bias = True  # bias of conv layer True or False
#             self.dropout = 0.0  # dropout rate
#             self.use_dilation = True  # use dilated knn or not
#             self.epsilon = 0.2  # stochastic epsilon for gcn
#             self.use_stochastic = False  # stochastic for gcn, True or False
#             self.drop_path = drop_path_rate
#             self.blocks = [2, 2, 18, 2]  # number of basic blocks in the backbone
#             self.channels = [128, 256, 512, 1024]  # number of channels of deep features
#             self.n_classes = num_classes  # Dimension of out_channels
#             self.emb_dims = 1024  # Dimension of embeddings
#
#     opt = OptInit(**kwargs)
#     model = DeepGCN(opt)
#     model.default_cfg = default_cfgs['vig_b_224_gelu']
#     return model
