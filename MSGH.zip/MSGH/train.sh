#!/bin/bash

rm train.log
nohup python train.py > train.log 2>&1 &
