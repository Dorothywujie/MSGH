import argparse
import copy
import logging
import os
import random
import sys
import time
import numpy as np
import torch
import torch.nn as nn
import torch.distributed as dist
import torch.optim as optim
from tensorboardX import SummaryWriter
#from torch.cuda.amp import autocast
from torch.nn.modules.loss import CrossEntropyLoss
from torch.utils.data import DataLoader
from tqdm import tqdm
import torch.nn.functional as F

# from test import inference
from utils import DiceLoss, BoundaryLoss, BoundaryDoULoss
from torchvision import transforms
from mutils import ramps, losses
from tools.data_parallel import BalancedDataParallel

logger = logging.getLogger('trainer')
logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
logger.addHandler(handler)



def trainer_ACDC(args, model, snapshot_path=None):
    from dataset_utils.dataset_ACDC import ACDC_dataset, RandomGenerator
    logging.info(str(args))
    base_lr = args.base_lr
    num_classes = args.num_classes
    batch_size = args.batch_size * (args.n_gpu-1) + args.gpu0_bsz

    db_train = ACDC_dataset(base_dir=args.root_path, list_dir=args.list_dir, split="train",
                            transform=transforms.Compose(
                                [RandomGenerator(output_size=[args.img_size, args.img_size])]))

    print("The length of train set is: {}".format(len(db_train)))

    def worker_init_fn(worker_id):
        random.seed(args.seed + worker_id)

    trainloader = DataLoader(db_train, batch_size=batch_size, shuffle=True, num_workers=8, pin_memory=True,
                             worker_init_fn=worker_init_fn)

    if args.n_gpu > 1:
        #model = nn.DataParallel(model)
        model = BalancedDataParallel(args.gpu0_bsz, model)

    model.train()
    ce_loss = CrossEntropyLoss()
    dice_loss = DiceLoss(num_classes)
    cosin_loss = nn.CosineSimilarity()
    boundary_loss = BoundaryDoULoss(args.num_classes)
    optimizer = optim.SGD(model.parameters(), lr=base_lr, momentum=0.9, weight_decay=0.0001)
    # optimizer = optim.Adam(model.parameters(), lr=base_lr, weight_decay=0.0001)

    iter_num = 0
    max_epoch = args.max_epochs
    max_iterations = args.max_epochs * len(trainloader)  # max_epoch = max_iterations // len(trainloader) + 1

    model.train()
    iterator = tqdm(range(max_epoch), ncols=70)
    #pipline = transforms.Compose([
    #    # 正则化
    #    transforms.Normalize([0.5], [0.5]),
    #    transforms.RandomResizedCrop(224),
    #    transforms.RandomHorizontalFlip(),
    #])
    weak_pipline1 = transforms.Compose([
        transforms.Normalize([0.5], [0.5]),
        transforms.RandomResizedCrop(224, scale=(0.2, 1.0)),
        transforms.RandomHorizontalFlip(),
        #transforms.RandomVerticalFlip(),
    ])

    strong_pipline2 = transforms.Compose([
        transforms.Normalize([0.5], [0.5]),
        transforms.RandomResizedCrop(224, scale=(0.2, 1.0)),
        transforms.RandomRotation(45),
        transforms.RandomVerticalFlip(),
    ])

    # MoCo v2's aug: similar to SimCLR https://arxiv.org/abs/2002.05709
    strong_pipline = transforms.Compose([
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        transforms.RandomResizedCrop(224, scale=(0.2, 1.)),
        transforms.RandomApply([
            transforms.ColorJitter(0.4, 0.4, 0.4, 0.1)  # not strengthened
            ], p=0.8),
        transforms.RandomGrayscale(p=0.2),
        #transforms.RandomApply([GaussianBlur([.1, 2.])], p=0.5),
        transforms.RandomHorizontalFlip(),
    ])

    start_epoch = 0
    for epoch_num in iterator:
        for i_batch, sampled_batch in tqdm(enumerate(trainloader), bar_format='{l_bar}{bar:30}{r_bar}{bar:-10b}',position=0, ncols=70):
            image_batch, label_batch = sampled_batch['image'], sampled_batch['label']
            image_batch = image_batch.cuda()
            label_batch = label_batch.cuda()
            
            # from IPython import embed; embed()
            # exit()
            if image_batch.shape[1] == 1:
                image_batch = image_batch.repeat(1, 3, 1, 1)
            image_aug1 = strong_pipline(image_batch)
            image_aug2 = strong_pipline(image_batch)
            
            image_batch = image_batch.mean(dim=1, keepdim=True)
            image_aug1 = image_aug1.mean(dim=1, keepdim=True)
            image_aug2 = image_aug2.mean(dim=1, keepdim=True)

            outputs, out2, p_o, p_a, z_o, z_a = model(image_batch, image_aug1, image_aug2)
            #outputs = model(image_batch, image_aug1, image_aug2)

            #con_loss = 1 - cosin_loss(out1, out2).mean() #一致性损失

            loss_contrast = -(cosin_loss(p_o, z_a).mean() + cosin_loss(p_a, z_o).mean()) * 0.5
            
            #loss_ce = ce_loss(outputs, label_batch[:].long())
            #loss_dice = dice_loss(outputs, label_batch, softmax=True)
           
            #loss_ce1 = ce_loss(outputs1, label_batch[:].long())
            #loss_dice1 = dice_loss(outputs1, label_batch, softmax=True)
            
            loss_boundary = boundary_loss(outputs, label_batch[:])  # for our boundary DoU loss

            #loss = 0.45 * loss_ce + 0.45 * loss_dice  + 0.05 * loss_ce1 + 0.05 * loss_dice1 + 0.05 * loss_contrast
            loss = loss_boundary + 0.01 * loss_contrast
           #loss =  0.5 * loss_ce + 0.5 * loss_dice

            # loss.backward()
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        

            lr_ = base_lr * (1.0 - iter_num / max_iterations) ** 0.9
            for param_group in optimizer.param_groups:
                param_group['lr'] = lr_
            
            epoch_num = start_epoch + epoch_num
            if iter_num % 5 == 0:
                logger.info('epoch: {}/{}\t'
                            'batch:{:>4d}/{}\t'
                            # 'cross_loss:{:.3f}\t'
                            # 'dice_loss:{:.3f}\t'
                            # 'cross_loss:{:.3f}\t'
                            # 'dice_loss:{:.3f}\t'
                            'loss_boundary:{:.3f}\t'
                            'loss_contrast:{:.3f}\t'
                            'loss:{:.3f}\t'.format(
                                start_epoch + epoch_num,
                                max_epoch,
                                i_batch,
                                len(trainloader),
                                # loss_ce,
                                # loss_dice,
                                # loss_ce1,
                                # loss_dice1,
                                loss_boundary,
                                loss_contrast,
                                loss
                ))
            iter_num = iter_num + 1

            #print('iteration %d : loss : %f, loss_ce: %f, loss_contrast: %f' % (iter_num, loss.item(), loss_ce.item(), loss_contrast.item()))

        save_interval = 50  # int(max_epoch/6)
        if (epoch_num > int(max_epoch / 2) or epoch_num >= 49) and (epoch_num + 1) % save_interval == 0:
            save_mode_path = os.path.join(snapshot_path, 'epoch_' + str(epoch_num) + '.pth')
            torch.save(model.state_dict(), save_mode_path)
            logging.info("save model to {}".format(save_mode_path))

        if epoch_num >= max_epoch - 1:
            save_mode_path = os.path.join(snapshot_path, 'epoch_' + str(epoch_num) + '.pth')
            torch.save(model.state_dict(), save_mode_path)
            logging.info("save model to {}".format(save_mode_path))
            iterator.close()
            break
class GaussianBlur(object):
    """Gaussian blur augmentation in SimCLR https://arxiv.org/abs/2002.05709"""
    def __init__(self, sigma=[0.1, 2.0]):
        self.sigma = sigma
    def __call__(self, x):
        sigma = random.uniform(self.sigma[0], self.sigma[1])
        x = x.filter(ImageFilter.GaussianBlur(radius=sigma))
        return x

